class CheckListModel{
  bool check;var model;

  CheckListModel(this.check, this.model);
}