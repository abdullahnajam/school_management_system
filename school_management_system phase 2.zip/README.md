# school_management_system
 flutter project for school MIS
